﻿پروژه: مدل‌سازی زنجیره تأمین در شرایط تورمی – پارس کنترل خودرو
چگونه نوسانات طلا و دلار بر هزینه‌های عملیاتی تأثیر می‌گذارد؟

محتوای بسته
------------
1-Proposal/ParsControl-Proposal.docx   پروپوزال کامل (نسخه‌ی Word)
1-Proposal/ParsControl-Proposal.pdf    همان پروپوزال برای مطالعه و چاپ
2-Presentation/ParsControl-Presentation.html   ارائه‌ی تعاملی (۱۴ اسلاید)
3-PowerBI/ParsControl-Dashboard.pbit   قالب داشبورد Power BI (۴ صفحه)
4-Database/ParsControlDB.bak           نسخه‌ی پشتیبان پایگاه داده‌ی SQL Server

ارائه
-----
فایل HTML را با Chrome یا Edge باز کنید.
جابه‌جایی بین اسلایدها: کلیدهای جهت یا Space  |  تمام‌صفحه: کلید F
اسلاید ۱۰ شبیه‌ساز زنده‌ی شوک ارزی است و اسلایدرهای آن را می‌توان حین ارائه تغییر داد.

راه‌اندازی داشبورد Power BI
---------------------------
1. در SQL Server Management Studio روی Databases راست‌کلیک کنید، Restore Database را بزنید
   و فایل 4-Database/ParsControlDB.bak را با نام ParsControlDB بازیابی کنید.
2. فایل 3-PowerBI/ParsControl-Dashboard.pbit را با Power BI Desktop باز کنید.
   داشبورد به سرور محلی پیش‌فرض (.) وصل می‌شود و داده‌ها را بارگذاری می‌کند.
3. اگر SQL Server روی نمونه یا سرور دیگری است (مثلاً .\SQLEXPRESS):
   Transform data > Data source settings > Change Source، نام سرور را اصلاح کنید و Refresh بزنید.

نکته
----
داده‌ها برای نمایش روش شبیه‌سازی شده‌اند (شاخص طلا و هزینه‌های عملیاتی «فرضی» برچسب خورده‌اند).
